public class RifleUsing implements WeaponUsing{
    @Override
    public void useWeapon() {
        System.out.println("Use rifle");
    }
}
