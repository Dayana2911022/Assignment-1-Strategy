public interface CombatVehicleUsing {
    void useCombatVehicle();
}
