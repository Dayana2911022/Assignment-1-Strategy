public class TankUsing implements CombatVehicleUsing{
    @Override
    public void useCombatVehicle() {
        System.out.println("Combat vehicle is a tank!");
    }
}
