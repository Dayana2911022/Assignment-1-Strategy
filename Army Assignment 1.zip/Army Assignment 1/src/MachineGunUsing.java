public class MachineGunUsing implements WeaponUsing{
    @Override
    public void useWeapon() {
        System.out.println("Use Machine Gun");
    }
}
