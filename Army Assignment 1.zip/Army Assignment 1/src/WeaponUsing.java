public interface WeaponUsing {
    void useWeapon();
}
