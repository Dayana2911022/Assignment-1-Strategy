public class WeaponOnly implements WeaponUsing{
    @Override
    public void useWeapon() {
        System.out.println("Just Weapon");
    }
}
