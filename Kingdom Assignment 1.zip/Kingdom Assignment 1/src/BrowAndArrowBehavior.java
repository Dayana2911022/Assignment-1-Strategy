public class BrowAndArrowBehavior implements WeaponBehavior{
    @Override
    public void useWeapon() {
        System.out.println("/I am using brow and weapon!");
    }
}
