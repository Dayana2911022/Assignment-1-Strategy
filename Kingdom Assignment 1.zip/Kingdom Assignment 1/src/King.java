public class King extends Character{
    public King(WeaponBehavior weaponBehavior) {
        super(weaponBehavior);
    }

    public void fight() {

    }

    @Override
    public void display() {

    }
}
