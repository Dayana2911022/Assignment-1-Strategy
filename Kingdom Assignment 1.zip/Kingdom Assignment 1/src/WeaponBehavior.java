public interface WeaponBehavior {
    void useWeapon();
}
