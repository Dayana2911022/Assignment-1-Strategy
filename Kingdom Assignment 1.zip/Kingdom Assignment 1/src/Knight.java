public class Knight extends Character{

    public Knight(WeaponBehavior weaponBehavior) {
        super(weaponBehavior);
    }

    public void fight() {

    }

    @Override
    public void display() {

    }
}
